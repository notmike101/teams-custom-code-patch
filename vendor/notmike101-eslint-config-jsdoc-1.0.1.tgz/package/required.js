export { jsdocRequired as default } from './index.js';
