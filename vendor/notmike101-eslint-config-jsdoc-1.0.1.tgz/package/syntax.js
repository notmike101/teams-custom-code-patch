export { jsdocSyntax as default } from './index.js';
